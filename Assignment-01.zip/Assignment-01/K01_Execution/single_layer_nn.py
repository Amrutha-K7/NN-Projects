# Kenchanagowdra, Amrutha
# 1001_861_876
# 2021_09_26
# Assignment_01_01

import numpy as np

class SingleLayerNN(object):
    def __init__(self, input_dimensions=2,number_of_nodes=4):
        """
        Initialize SingleLayerNN model and set all the weights and biases to random numbers.
        :param input_dimensions: The number of dimensions of the input data
        :param number_of_nodes: Note that number of neurons in the model is equal to the number of classes.
        """
        self.input_dimensions = input_dimensions
        self.number_of_nodes = number_of_nodes
        self.initialize_weights()

    def initialize_weights(self,seed=None):
        """
        Initialize the weights, initalize using random numbers.
        If seed is given, then this function should
        use the seed to initialize the weights to random numbers.
        :param seed: Random number generator seed.
        :return: None
        """
        if seed != None:
            np.random.seed(seed)
        self.weights = np.random.randn(self.number_of_nodes, self.input_dimensions + 1)
        #weights initialized for seed =2
        #[[-0.41675785 -0.05626683 -2.1361961 ]
        #[ 1.64027081 -1.79343559 -0.84174737]]

    def set_weights(self, W):
        """
        This function sets the weight matrix (Bias is included in the weight matrix).
        :param W: weight matrix
        :return: None if the input matrix, w, has the correct shape.
        If the weight matrix does not have the correct shape, this function
        should not change the weight matrix and it should return -1.
        """

        if W.shape[0] == self.number_of_nodes and \
        W.shape[1] == (self.input_dimensions + 1):
            self.weights = W
            return None
        else:
            return -1


    def get_weights(self):
        """
        This function should return the weight matrix(Bias is included in the weight matrix).
        :return: Weight matrix
        """
        return self.weights

    def predict(self, X):
        """
        Make a prediction on a batach of inputs.
        :param X: Array of input [input_dimensions,n_samples]
        :return: Array of model [number_of_nodes ,n_samples]
        Note that the activation function of all the nodes is hard limit.
        """

        #including the bias as first row in the given input matrix (X)
        #and taking the transpose to iterate parallely for each sample

        first_row_ones = np.ones([1, X[0].size])
        self.input_matrix = np.concatenate((first_row_ones, X)).transpose()

        #lets create an array to append the predicted output, initially filled with ones
        #shape of the output array should be number_of_classes x number of input samples,
        #its been transposed to iterate parallely with input samples

        self.output_matrix = np.ones([self.number_of_nodes, X[0].size], int).transpose()

        #zipping input and output matrices together for parallel iteration
        io_zip = zip(self.input_matrix, self.output_matrix)

        #iterating through each input sample from input matrix with corresponding output matrix
        for (each_input_row, each_output_row) in io_zip:
            #iterating for each node/neuron to caluculate the net for each node
            for node in range(self.number_of_nodes):
                # zipping each input sample row with respective weight matrix row
                input_weight_zip = zip(each_input_row, self.get_weights()[node])
                predicted_output = None
                netweight = 0
                #iterate through respective weights and input samples and calculated netweight for each neuron
                for (input_element, weight_element) in input_weight_zip:
                    netweight = netweight + (input_element * weight_element)

               #Hardlimit function implementation to predict the output
                if netweight < 0:
                    predicted_output = 0
                else:
                    predicted_output = 1
                #updating the predicted output for netweight calculated for each neuron
                each_output_row[node] = predicted_output

        return (self.output_matrix.transpose())


    def train(self, X, Y, num_epochs=10,  alpha=0.1):
        """
        Given a batch of input and desired outputs, and the necessary hyperparameters (num_epochs and alpha),
        this function adjusts the weights using Perceptron learning rule.
        Training should be repeated num_epochs times.
        :param X: Array of input [input_dimensions,n_samples]
        :param y: Array of desired (target) outputs [number_of_nodes ,n_samples]
        :param num_epochs: Number of times training should be repeated over all input data
        :param alpha: Learning rate
        :return: None
        """
        #loop to be executed as many as num_epochs times
        for each_epoch in range(num_epochs):

            # first row in the given input matrix (X) has been filled with ones
            # and taking the transpose to iterate parallely for each sample
            first_row_ones = np.ones([1, X[0].size])
            self.input_matrix = np.concatenate((first_row_ones,X)).transpose()

            # transpose of the desired output matrix has been taken to help with the parallel iteration through zip function
            self.desired_output_matrix = Y.transpose()

            # now lets get the prediction on input_matrix by calling predict method,
            # and transpose of the returned output_matrix is taken to help with the parallel iteration through zip function
            self.actual_output_matrix = self.predict(X).transpose()

            # zipping input_matrix, desired_output_matrix, actual_output_matrix and number of rows of desired_output_matrix to help with the parallel iteration of rows of samples
            input_desired_rows_zip = zip(self.input_matrix, self.desired_output_matrix,self.actual_output_matrix, range(len(self.desired_output_matrix)))

            # parallely iterate through each row of the 4 zipped matrices as mentioned above
            for (each_input_row, each_desired_row, each_actual_row,each_desired_rownumber) in input_desired_rows_zip:

                #loop through actual and desired outputs for each neuron and calculate the error as shown below
                for node in range(self.number_of_nodes):
                    error_difference = each_desired_row[node] - each_actual_row[node]
                    #loop through each input element in each_input_row and respective weights to adjust the weights
                    for (input_element, weight_element, weight_rownumber) in zip(each_input_row, self.get_weights()[node], range(len(self.get_weights()[node]))):
                        # weight adjustment to make the model predict better
                        weight_matrix = self.get_weights()
                        weight_matrix[node][weight_rownumber] = weight_element + (alpha * input_element * error_difference)
                        self.set_weights(weight_matrix)

                self.output_matrix = self.predict(X).transpose()

    def calculate_percent_error(self,X, Y):
        """
        Given a batch of input and desired outputs, this function calculates percent error.
        For each input sample, if the output is not the same as the desired output, Y,
        then it is considered one error. Percent error is 100*(number_of_errors/ number_of_samples).
        :param X: Array of input [input_dimensions,n_samples]
        :param y: Array of desired (target) outputs [number_of_nodes ,n_samples]
        :return percent_error
        """
        #first row in the given input matrix (X) has been filled with ones
        #and taking the transpose to iterate parallely for each sample
        first_row_ones = np.ones([1, X[0].size])
        self.input_matrix = np.concatenate((first_row_ones, X)).transpose()

        #transpose of the desired output matrix has been taken to help with the parallel iteration through zip function
        self.desired_output_matrix = Y.transpose()

        #now lets get the prediction on input_matrix by calling predict method,
        # and transpose of the returned output_matrix is taken to help with the parallel iteration through zip function
        self.actual_output_matrix = self.predict(X).transpose()

        #zipping input_matrix, desired_output_matrix and actual_output_matrix to help with the parallel iteration of rows of samples
        input_desired_actual_zip= zip(self.input_matrix, self.desired_output_matrix, self.actual_output_matrix)


        number_of_samples = 0
        number_of_errors = 0
        #iterate through each row of the 3 zipped matrices as mentioned above and count the samples and number of errors
        for (each_input_row, each_desired_row, each_actual_row) in input_desired_actual_zip:
            number_of_samples = number_of_samples + 1

            # loop through each node to compare the desired vs actual outputs for each neuron and count the number if errors
            for node in range(self.number_of_nodes):
                if each_desired_row[node] != each_actual_row[node]:
                    number_of_errors = number_of_errors + 1
                    break
        percent_error = 100*(number_of_errors / number_of_samples)
        return percent_error


if __name__ == "__main__":
    input_dimensions = 2
    number_of_nodes = 2

    model = SingleLayerNN(input_dimensions=input_dimensions, number_of_nodes=number_of_nodes)
    model.initialize_weights(seed=2)
    X_train = np.array([[-1.43815556, 0.10089809, -1.25432937, 1.48410426],
                        [-1.81784194, 0.42935033, -1.2806198, 0.06527391]])
    print(model.predict(X_train))
    Y_train = np.array([[1, 0, 0, 1], [0, 1, 1, 0]])
    print("****** Model weights ******\n",model.get_weights())
    print("****** Input samples ******\n",X_train)
    print("****** Desired Output ******\n",Y_train)
    percent_error=[]
    for k in range (20):
        model.train(X_train, Y_train, num_epochs=1, alpha=0.1)
        percent_error.append(model.calculate_percent_error(X_train,Y_train))
    print("******  Percent Error ******\n",percent_error)
    print("****** Model w eights ******\n",model.get_weights())